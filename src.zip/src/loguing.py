import tkinter as tk

ventana = tk.Tk()
ventana.geometry("300x300")
ventana.title("Loguing biblioteca")
#ventana.iconbitmap("imag1.webp")

lblUsuario = tk.Label(ventana,text="Usuario")
lblUsuario.pack()

txtUsuario = tk.Entry(ventana)
txtUsuario.pack()

lblClave = tk.Label(ventana,text="Contraseña")
lblClave.pack()

txtClave = tk.Entry(ventana,show="*")
txtClave.pack()

btnAceptar = tk.Button(ventana, text="Aceptar")
btnAceptar.pack()

ventana.mainloop()
