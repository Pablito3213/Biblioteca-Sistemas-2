import React, { useState } from 'react';
import './App.css';
import Socios from './socios.jsx';

// COMPONENTE PRINCIPAL
function App() {

  const [logeado, setLogeado] = useState(false);
  const [mostrarSocios, setMostrarSocios] = useState(false);

  if (!logeado) {
    return <Login onLoginSuccess={() => setLogeado(true)} />;
    
  }

  return (
    <div className="container-biblioteca">

      {/* TITULO */}
      <div className="seccion-titulo">

        <h1 className="nombre-biblioteca">
          La biblioteca de todos
        </h1>

        <p className="subtitulo-biblioteca">
          Un lugar donde cada libro tiene una historia por contar
        </p>

      </div>

      {/* CITA DEL DIA */}
      <div className="seccion-centro">

        <div className="tarjeta-cita">

          <h5 className="cita-titulo">
            📖 Cita del día
          </h5>

          <p className="cita-texto">
            "Para viajar lejos, no hay mejor nave que un libro."
          </p>

          <footer className="cita-autor">
            — Emily Dickinson
          </footer>

        </div>

      </div>

      {/* BOTONES */}
      <div className="seccion-botones">

        <button
          className="btn-gestion"
          onClick={() => setMostrarSocios(true)}
        >
          😎 Socios
        </button>

        <button className="btn-gestion">📖 Libro</button>
        <button className="btn-gestion">🕵 Usuarios</button>
        <button className="btn-gestion">🪙 Pagos</button>
        <button className="btn-gestion">📚 Prestamos</button>
        <button className="btn-gestion">📝 Devolucion</button>

        <button
          className="btn-gestion btn-cerrar"
          onClick={() => setLogeado(false)}
        >
          Cerrar Sesión
        </button>

      </div>

      {/* VENTANA DE SOCIOS */}
      <Socios
        mostrar={mostrarSocios}
        cerrar={() => setMostrarSocios(false)}
      />

    </div>
  );
}


// COMPONENTE LOGIN
function Login({ onLoginSuccess }) {

  const [usuario, setUsuario] = useState('');
  const [clave, setClave] = useState('');

  const manejarEnvio = (e) => {
    e.preventDefault();

    if (usuario === "admin" && clave === "1234") {
      onLoginSuccess();
    } else {
      alert("Usuario o contraseña incorrectos.");
    }
  };

  return (

    <div className="login-contenedor">

      <form className="login-formulario" onSubmit={manejarEnvio}>

        <h2 className="login-titulo">
          Login biblioteca
        </h2>

        <div className="login-campo">

          <label>Usuario</label>

          <input
            type="text"
            value={usuario}
            onChange={(e) => setUsuario(e.target.value)}
          />

        </div>

        <div className="login-campo">

          <label>Contraseña</label>

          <input
            type="password"
            value={clave}
            onChange={(e) => setClave(e.target.value)}
          />

        </div>

        <button type="submit" className="btn-login">
          Aceptar
        </button>

      </form>

    </div>
  );
}

export default App;
